var Config = new Object();
Config.closeKeys = [113, 27];
Config.UseGoldItem = false;
Config.AddGoldItem = false;
Config.AddDollarItem = false;
Config.AddAmmoItem = false;
Config.DoubleClickToUse = true;
